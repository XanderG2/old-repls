<?PHP
echo shell_exec("script.py");
?>