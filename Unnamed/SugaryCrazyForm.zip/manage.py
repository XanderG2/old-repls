#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
game = input("What game do you want to play? ")

if game == "bomb" or "bombdodger":
  print("hi")
else:
  print("Thats not a game")